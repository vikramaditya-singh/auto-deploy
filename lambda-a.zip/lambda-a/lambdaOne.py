def test_lambda(event, context):
    print("Hi Vikram")